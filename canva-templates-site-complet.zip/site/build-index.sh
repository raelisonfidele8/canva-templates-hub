#!/bin/bash
# Run this script after adding new product/review files
# It auto-generates the index.json files

echo "Building product index..."
cd products
ls *.json 2>/dev/null | grep -v index.json | python3 -c "
import sys, json
files = [f.strip() for f in sys.stdin if f.strip()]
print(json.dumps(sorted(files), indent=2))
" > index.json
echo "Products index: $(cat index.json | python3 -c 'import sys,json;d=json.load(sys.stdin);print(len(d)," files")')"

cd ../reviews
ls *.json 2>/dev/null | grep -v index.json | python3 -c "
import sys, json
files = [f.strip() for f in sys.stdin if f.strip()]
print(json.dumps(sorted(files), indent=2))
" > index.json
echo "Reviews index: $(cat index.json | python3 -c 'import sys,json;d=json.load(sys.stdin);print(len(d)," files")')"

echo "Done!"
